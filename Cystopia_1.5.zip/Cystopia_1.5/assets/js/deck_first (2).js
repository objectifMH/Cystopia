"use strict";


document.addEventListener("DOMContentLoaded", function(){
console.log(" Mon fichier deck Html est bien chargé ");

let myForm = document.getElementById('choix_deck_form');
console.log(myForm);

let mySubmit = document.getElementById('choixsubmit');
console.log(mySubmit);


//$(".new_deck").hide();

$(".carte_dos").click(function(){
    var borderValide = /borderValide/;
    var resulBorderV = borderValide.test($(this).attr('class'));
    if ( resulBorderV)
    {
        $(this).removeClass('borderValide');
    }
    else{
        $(this).addClass('borderValide');
    }



})


myForm.addEventListener("submit",function(event){
//console.log("Formulaire envoyé");
    //event.preventDefault();
let data = new FormData(myForm);

        //data.append('control', 'deck');
        //data.append('action', 'verifCreateTeam');
        //console.log(data.get('choix_cartes_team20'));
        ajax('./index.php?control=deck&action=verifCreateTeam', data, function(e) {

            //myForm.style.border = '4px solid red';
            console.log(e);
            if (e !== "") {

                let jsDec = JSON.parse(e);

                console.log(jsDec);

                if ( jsDec['validateTeam'] == 0) {



                    //document.getElementById("idNomCre").removeChild(divCrea);
                    if (jsDec["txtCreatures"]) {
                        document.getElementById("idCrea").innerText = jsDec["txtCreatures"];
                        document.getElementById("idCrea").style.display = "block";
                        document.getElementById("idCrea").className = "rouge";
                    }
                    else {
                        document.getElementById("idCrea").innerText = " Vous avez choisi 4 creatures ";
                        document.getElementById("idCrea").className = "bleue";
                    }
                    if (jsDec["txtBoucliers"]) {
                        document.getElementById("idBou").innerText = jsDec["txtBoucliers"];
                        document.getElementById("idBou").style.display = "block";
                        document.getElementById("idBou").className = "rouge";
                    }
                    else {
                        document.getElementById("idBou").innerText = " Vous avez choisi 3 boucliers ";
                        document.getElementById("idBou").className = "bleue";
                    }
                    if (jsDec["txtSorts"]) {
                        document.getElementById("idSor").innerText = jsDec["txtSorts"];
                        document.getElementById("idSor").style.display = "block";
                        document.getElementById("idSor").className = "rouge";
                    }
                    else {
                        document.getElementById("idSor").innerText = " Vous avez choisi 4 sorts ";
                        document.getElementById("idSor").className = "bleue";
                    }
                    if (jsDec["txtCreatures"] == "" && jsDec["txtBoucliers"] == "" && jsDec["txtSorts"] == "") {
                        let nomDeck = document.createElement("p");
                        nomDeck.innerText = " Veuillez saisir le nom de votre deck";
                        nomDeck.className = "bleue";
                        document.getElementById("choix_deck_form").appendChild(nomDeck);


                    }
                }
                else{
                    if ( jsDec['validateTeam'] == 1)
                    {
                       // $(".new_deck").show();
                    }
                }
            }

//ajax()
});

});
});

function ajax(file, data, fct) {
    var query = new XMLHttpRequest();
    query.onreadystatechange = function(e) {
        if(this.readyState == 4 && this.status == 200)
       {
       		//console.log("dans mon ajax");
       		//console.log(query.responseText);
            fct(query.responseText);
       } 
           
    };
    query.open('POST', file, true);
    query.send(data);
}