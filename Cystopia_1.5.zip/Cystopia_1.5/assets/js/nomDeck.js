"use strict"


document.addEventListener("DOMContentLoaded", function() {
    console.log(" Mon fichier deck Html est bien chargé ");


    console.log("dans nomDeck");
    //on cache le submit


    $("#choixsubmit").hide();


    $("#idNomDeck").on('keyup', function(fct){
        console.log(" on my key up");
        let myForm = document.getElementById('idNommDeckform');
        let data = new FormData(myForm);

        ajax('./index.php?control=deck&action=verifNomDeck', data, function (e) {
            console.log(e);

            if (e !== "")
            {


                    var jsDec = JSON.parse(e);
                    console.log("dans try");
                    //console.log(jsDec);
                    //console.log(jsDec["nomDeck"]);
                    //console.log(jsDec["validateNomTeam"]);
                    if ( jsDec["validateNomTeam"] == 1)
                    {
                        $("#idErreurNomDeck").show();
                        $("#idErreurNomDeck").attr("class","rouge");
                        $("#idErreurNomDeck").html("Vos avez déjà un deck avec ce 'nom'");
                        $("#choixsubmit").hide();
                    }
                    else{
                        //if (  jsDec["validateNomTeam"].length > 4)
                        {
                            $("#idErreurNomDeck").show();
                            $("#idErreurNomDeck").attr("class","bleue");
                            $("#idErreurNomDeck").html("Le nom de votre deck sera "+jsDec['nomDeck']);

                            $("#choixsubmit").show();
                        }
                    }


            }
        });
    });




});

function ajax(file, data, fct) {
    var query = new XMLHttpRequest();
    query.onreadystatechange = function(e) {
        if(this.readyState == 4 && this.status == 200)
        {
            fct(query.responseText);
        }

    };
    query.open('POST', file, true);
    query.send(data);
}