"use strict";


document.addEventListener("DOMContentLoaded", function() {
    console.log(" Mon fichier deck Html est bien chargé ");

    let myForm = document.getElementById('choix_deck_form');
    console.log(myForm);

    let mySubmit = document.getElementById('choixsubmit');
    console.log(mySubmit);


    //on cache le submit
    $(".new_deck").hide();

$(".carte_dos").click(function() {
    // on cache le submit fant que le nombre de cartes n'est pas atteint
    $(".new_deck").hide();


    var borderValide = /borderValide/;
    var resulBorderV = borderValide.test($(this).attr('class'));
    if (resulBorderV) {
        $(this).removeClass('borderValide');
    }
    else {
        $(this).addClass('borderValide');
    }

    let data = new FormData(myForm);
    let forInput = $(this).attr('for') ;
    //console.log($("#"+forInput));

    let input = $("#"+forInput);

    if (input.is(':checked')){
        //console.log(forInput + " est checked"+ $("#"+forInput).attr('class'));
        data.delete($("#" + forInput).attr("name"));
    }else {
        data.append(input.attr("name"), input.attr("value"));
        //console.log(forInput + " n'est malheuresement pas checked" + $("#"+forInput).attr('class'));


    }

    ajax('./index.php?control=deck&action=verifCreateTeam', data, function (e) {

        //myForm.style.border = '4px solid red';
        //console.log("premier appel ajax");
        console.log(e);
        if (e !== "")
        {

            try{
                var jsDec = JSON.parse(e);
            }
            catch(e){

        }

            console.log(jsDec);
            console.log(jsDec["txtCreatures"]);

            //if (jsDec['validateTeam'] == 0)
            {



                //document.getElementById("idNomCre").removeChild(divCrea);
                if (jsDec["txtCreatures"]) {
                    document.getElementById("idCrea").innerText = jsDec["txtCreatures"];
                    document.getElementById("idCrea").style.display = "block";
                    document.getElementById("idCrea").className = "rouge";
                }
                else {
                    document.getElementById("idCrea").innerText = " Vous avez choisi 4 creatures ";
                    document.getElementById("idCrea").className = "bleue";
                }
                if (jsDec["txtBoucliers"]) {
                    document.getElementById("idBou").innerText = jsDec["txtBoucliers"];
                    document.getElementById("idBou").style.display = "block";
                    document.getElementById("idBou").className = "rouge";
                }
                else {
                    document.getElementById("idBou").innerText = " Vous avez choisi 3 boucliers ";
                    document.getElementById("idBou").className = "bleue";
                }
                if (jsDec["txtSorts"]) {
                    document.getElementById("idSor").innerText = jsDec["txtSorts"];
                    document.getElementById("idSor").style.display = "block";
                    document.getElementById("idSor").className = "rouge";
                }
                else {
                    document.getElementById("idSor").innerText = " Vous avez choisi 4 sorts ";
                    document.getElementById("idSor").className = "bleue";
                }
                if (jsDec["txtCreatures"] == "" && jsDec["txtBoucliers"] == "" && jsDec["txtSorts"] == "") {
                    let nomDeck = document.createElement("p");
                    nomDeck.innerText = " Veuillez saisir le nom de votre deck";
                    nomDeck.className = "bleue";
                    document.getElementById("choix_deck_form").appendChild(nomDeck);


                }
            }
            //else
                {
                    if (jsDec['validateTeam'] == 1) {
                        $(".new_deck").show();

                        document.getElementById("idCrea").innerText = " Vous avez choisi 4 creatures ";
                        document.getElementById("idCrea").className = "bleue";

                        document.getElementById("idBou").innerText = " Vous avez choisi 3 boucliers ";
                        document.getElementById("idBou").className = "bleue";

                        document.getElementById("idSor").innerText = " Vous avez choisi 4 sorts ";
                        document.getElementById("idSor").className = "bleue";
                    }
                }

            }

        });
    })
});

function ajax(file, data, fct) {
    var query = new XMLHttpRequest();
    query.onreadystatechange = function(e) {
        if(this.readyState == 4 && this.status == 200)
       {
       		//console.log("dans mon ajax");
       		//console.log(query.responseText);
            fct(query.responseText);
       } 
           
    };
    query.open('POST', file, true);
    query.send(data);
}