<?php
echo " Post >> >> >>";
//var_dump($_POST);

if(isset($_POST['inputText']))
echo " choix inputText" . $_POST['inputText'];


if (isset($_POST['control'])){
	if ($_POST['control'] == "deck")
	{
		echo " le controlleur est deck ";
	}
	else{
		echo " pas de controlleur";
	}
}