<?php

class plateauModel extends coreModel
{

}