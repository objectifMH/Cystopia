<script type="text/javascript" src="assets/js/deck.js"></script>
<form  id="choix_deck_form" action="./index.php?control=deck&action=nomDeckDisplay" method="post" role="form" >

<?php
//    var_dump($cartes); ?control=deck&action=addDeck


        //intiatilisation des différents type de cartes
        $creaturesTitre = " <div class='nomType' id='idNomCre'> Creatures </div><p id='idCrea' class='rouge' ></p>";
        $sortsTitre =     " <div class='nomType' id='idNomSor'> Sorts </div><p id='idSor' class='rouge' ></p>";
        $boucliersTitre = " <div class='nomType' id='idNomBou'> Boucliers </div><p id='idBou' class='rouge' '></p>";
        
        $creatures = "";
        $sorts =     "";
        $boucliers = "";
        echo "<pre>";
        //var_dump($cartes);
        echo "</pre>";
        if ($cartes) {

            $decal = 140;
            for ( $i = 1; $i < 3 ; $i++) {


                foreach ($cartes as $val) {
                    $idCreature = $val->getId();
                    $type = $val->getType();


                    $creature = "";
                    switch ($idCreature) {
                        case 1:
                            $creature = '1_naruto.png';
                            break;
                        case 2:
                            $creature = '1_luffy.png';
                            break;
                        case 3:
                            $creature = '1_mononoke.png';
                            break;
                        case 4:
                            $creature = '1_eva.png';
                            break;
                        case 5:
                            $creature = '1_kaneda.png';
                            break;
                        case 6:
                            $creature = '1_motoko.png';
                            break;
                        case 7:
                            $creature = '1_deathnote.png';
                            break;
                        case 8:
                            $creature = '1_eclair.png';
                            break;
                        case 9:
                            $creature = '1_marteau.png';
                            break;
                        case 10:
                            $creature = '1_goldorak.png';
                            break;
                        case 11:
                            $creature = '1_alphonse.png';
                            break;
                        case 12:
                            $creature = '1_son-goku.png';
                            break;
                        case 13:
                            $creature = '2_sentinelle.png';
                            break;
                        case 14:
                            $creature = '2_chappie.png';
                            break;
                        case 15:
                            $creature = '2_quorra.png';
                            break;
                        case 16:
                            $creature = '2_adam.png';
                            break;
                        case 17:
                            $creature = '2_roy.png';
                            break;
                        case 18:
                            $creature = '2_major.png';
                            break;
                        case 19:
                            $creature = '2_zf-1.png';
                            break;
                        case 20:
                            $creature = '2_virus.png';
                            break;
                        case 21:
                            $creature = '2_sentence.png';
                            break;
                        case 22:
                            $creature = '2_t800.png';
                            break;
                        case 23:
                            $creature = '2_daddy.png';
                            break;
                        case 24:
                            $creature = '2_robocop.png';
                            break;
                    }
                    $nomDeck = $val->getNom();
                    if (strlen($nomDeck) > 12) {
                        $nomDeck = substr($nomDeck, 0, 10) . "...";
                    }
                    $nomDeck = $nomDeck == "" ? " ... " : $nomDeck;


//                $divCarte = "<div class='carte_dos' style='    background-image: url(./assets/images/".$type."/".$creature.");'>
//                        <a href='?id=".$val->getId()."''>".' '."
//                            <p class='nomCarteDeck'>".$nomDeck."<input class='input_choix' type='checkbox' name='choix_cartes_team". $val->getId() ."' value=".$val->getId().">
//                            </p>
//                        </a>
//                    </div>";

                    switch ($type) {
                        case 1:
                            $type = 'creatures';
                            $creatures .= "
                        <label class='nomCarteDeck'><div class='labelSpan'>" . $nomDeck . "</div><input class='input_choix' type='checkbox' id='id".$i."_". $val->getId()."'  name='".$i."choix_cartes_team" . $val->getId() . "' value=" . $val->getId() . ">
                                <div class='carte_dos' for='id".$i."_". $val->getId()."' style='    background-image: url(./assets/images/" . $type . "/" . $creature . ");'>
                                
                                
                           
                        </div>
                        </label>
                        ";

                            break;
                        case 2:
                            $type = 'sorts';
                            $sorts .= "
                        <label class='nomCarteDeck'>
                            <div class='labelSpan'>" . $nomDeck . "</div>
                                <input class='input_choix' type='checkbox' id='id".$i."_". $val->getId()."'  name='".$i."choix_cartes_team" . $val->getId() . "' value=" . $val->getId() . ">
                            <div class='carte_dos' for='id".$i."_". $val->getId()."' style='    background-image: url(./assets/images/" . $type . "/" . $creature . ");'></div>
                        </label>";
                            break;
                        case 3:
                            $type = 'boucliers';
                            $boucliers .= "
                        <label class='nomCarteDeck'>
                            <div class='labelSpan'>" . $nomDeck . "</div>
                                <input class='input_choix' type='checkbox' id='id".$i."_". $val->getId()."'  name='".$i."choix_cartes_team" . $val->getId() . "' value=" . $val->getId() . ">
                            <div class='carte_dos' for='id".$i."_". $val->getId()."' style='    background-image: url(./assets/images/" . $type . "/" . $creature . ");'></div>
                        </label>";

                            break;
                        // case 4:
                        //     $type = 'creatures';
                        //     $creatures .="
                        //     <div class='carte_dos' style='    background-image: url(./assets/images/".$type."/".$creature.");'>

                        //             <p class='nomCarteDeck'>".$nomDeck."<input class='input_choix' type='checkbox' name='choix_cartes_team". $val->getId() ."' value=".$val->getId().">
                        //             </p>

                        //     </div>" ;
                        //     break;
                    }

                }
            }
            //echo '</div>';
            echo '<div class="container_deck">';
            echo $creaturesTitre;

                echo $creatures ."";
           // echo $creatures ."";
            echo "<hr>";
            echo $boucliersTitre;

            echo $boucliers."";
            //echo $boucliers."";
            echo "<hr>";
            echo $sortsTitre;
            echo $sorts."";
            //echo $sorts."";
            echo "</div>";
        }
    ?>
    <div class="new_deck">
       <!-- <a class="white" href="?control=deck&action=create">Valider</a> -->
        <input type="submit" name="choix_deck_submit" id="choixsubmit"  class="" value="Valider" >
        
    </div>
    
</form>
