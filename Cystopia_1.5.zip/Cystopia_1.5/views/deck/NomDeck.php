<link rel="stylesheet" type="text/css" href="assets/css/login.css">
<link rel="stylesheet" href="assets/css/font-awesome-4.7.0/css/font-awesome.min.css">
<script type="text/javascript" src="./assets/js/nomDeck.js"></script>

<form id="idNommDeckform" action="./index.php?control=deck&action=verifNomDeck" method="post" role="form" style="display: block;">';

<div class="panel-body">
    <div class="row">
        <div class="col-lg-12">
            <p id='idErreurNomDeck' class='rouge' ></p>
            <div class="form-group">
                <input type="text" name="choixNomDeck" id="idNomDeck"  class="form-control" placeholder="Nom de votre deck">
            </div>


        </div>
    </div>
</div>
<div class="new_deck">
    <input type="submit" name="choix_deck_submit" id="choixsubmit"  class="" value="Valider" >

</div>
</form>
