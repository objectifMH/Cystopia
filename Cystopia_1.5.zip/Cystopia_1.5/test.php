<?php
echo " post >>";
//var_dump($_POST);

if(isset($_POST['choix_deck_form']))
echo " choix submit" . $_POST['choix_deck_form'];


if (isset($_POST['control'])){
	if ($_POST['control'] == "deck")
	{
		echo " le controlleur est deck ";
	}
	else{
		echo " pas de controlleur";
	}
}